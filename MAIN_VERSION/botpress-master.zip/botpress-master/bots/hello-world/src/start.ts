import bot from './index'
void bot.start()
