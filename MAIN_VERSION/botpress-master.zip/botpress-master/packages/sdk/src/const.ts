export const botIdHeader = 'x-bot-id'
export const botUserIdHeader = 'x-bot-user-id'
export const integrationIdHeader = 'x-integration-id'
export const webhookIdHeader = 'x-webhook-id'

export const configurationHeader = 'x-bp-configuration'
export const operationHeader = 'x-bp-operation'
export const typeHeader = 'x-bp-type'
