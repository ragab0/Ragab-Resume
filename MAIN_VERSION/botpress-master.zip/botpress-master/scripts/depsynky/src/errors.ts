export class DepSynkyError extends Error {}
