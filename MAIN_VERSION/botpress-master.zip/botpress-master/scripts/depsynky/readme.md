# DepSynky

CLI to synchronize dependencies accross mono-repo
