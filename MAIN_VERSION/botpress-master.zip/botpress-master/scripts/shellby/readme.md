# Shellby

Just a function to run shell commands without having to handle the `child_process` API.
