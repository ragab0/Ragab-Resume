export const INTEGRATION_NAME = 'webchat'
export const INTEGRATION_STATE_TYPE = 'integration'
export const INTEGRATION_STATE_NAME = 'webchatintegration'
export const USER_DATA_STATE_NAME = 'userData'
