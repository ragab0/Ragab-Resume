export const INTEGRATION_NAME = 'github'
export const GITHUB_SIGNATURE_HEADER = 'x-hub-signature-256'
