import { findTarget } from './find-target'

export default {
  findTarget,
}
