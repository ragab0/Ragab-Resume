export const INTEGRATION_NAME = 'intercom'
