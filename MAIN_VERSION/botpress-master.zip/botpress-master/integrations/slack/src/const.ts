export const INTEGRATION_NAME = 'slack'
