export const INTEGRATION_NAME = 'zendesk'
